# TODO: Make Logo Visible on All Screen Sizes

- [x] Modify CSS in `css/style.css` to remove `display: none;` from `#menu-btn` to ensure the logo image is visible on all screen sizes.
- [ ] Test the changes to confirm the logo displays correctly on desktop and mobile.
